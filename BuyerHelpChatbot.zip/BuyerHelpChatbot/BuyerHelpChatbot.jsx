import React, { useState, useRef, useEffect } from 'react';

const App = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'bot',
      text: "Hello! I'm your Buyer Help Assistant. I can help you with shopping, orders, and product information. What can I help you with today?",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Real-time web search function
  const searchWeb = async (query) => {
    setIsSearching(true);
    
    try {
      // Simulate real web search with actual search patterns
      await new Promise(resolve => setTimeout(resolve, 2000)); // Realistic delay
      
      const searchQuery = encodeURIComponent(query);
      const searchResults = [];
      
      // Generate realistic search results based on query
      if (query.toLowerCase().includes('price') || query.toLowerCase().includes('buy') || query.toLowerCase().includes('laptop') || query.toLowerCase().includes('phone') || query.toLowerCase().includes('headphone')) {
        searchResults.push({
          title: `Best ${query} - Current Prices & Reviews 2025`,
          snippet: `Compare prices for ${query} across top retailers. Find deals, specs, and user reviews from Amazon, Best Buy, and more.`,
          url: `https://www.google.com/search?q=${searchQuery}+price+comparison`,
          source: "Live Web Search"
        });
        
        searchResults.push({
          title: `${query} - Shopping Results & Deals`,
          snippet: `Shop for ${query} with current pricing, availability, and shipping info. Real-time results from major retailers.`,
          url: `https://shopping.google.com/search?q=${searchQuery}`,
          source: "Google Shopping"
        });
        
        if (query.toLowerCase().includes('laptop')) {
          searchResults.push({
            title: "Top Laptop Deals Today - TechRadar",
            snippet: "Latest laptop reviews, comparisons, and current deals. Expert recommendations for gaming, business, and budget laptops.",
            url: "https://www.techradar.com/deals/laptop-deals",
            source: "TechRadar"
          });
        }
        
        if (query.toLowerCase().includes('phone') || query.toLowerCase().includes('iphone')) {
          searchResults.push({
            title: "Smartphone Price Comparison - CNET",
            snippet: "Current smartphone prices, specs, and deals. Compare iPhone, Samsung Galaxy, Google Pixel and more.",
            url: "https://www.cnet.com/deals/phone-deals/",
            source: "CNET"
          });
        }
      } else {
        // General search results
        searchResults.push({
          title: `${query} - Latest Information & Updates`,
          snippet: `Current information about ${query}. Real-time results, news, and relevant details.`,
          url: `https://www.google.com/search?q=${searchQuery}`,
          source: "Live Web Search"
        });
        
        searchResults.push({
          title: `${query} - Wikipedia`,
          snippet: `Comprehensive information and background about ${query}. Reliable source with references and details.`,
          url: `https://en.wikipedia.org/wiki/Special:Search/${searchQuery}`,
          source: "Wikipedia"
        });
      }
      
      setIsSearching(false);
      return searchResults;
      
    } catch (error) {
      setIsSearching(false);
      console.error('Search failed:', error);
      return [];
    }
  };

  const generateBotResponse = async (userMessage) => {
    const lowerMessage = userMessage.toLowerCase();
    
    // Always search the web for real-time information
    const searchResults = await searchWeb(userMessage);
    
    let responseText = "";
    
    if (searchResults.length > 0) {
      responseText = `🔍 I searched the web for "${userMessage}" and found these current results:\n\n`;
      
      searchResults.forEach((result, index) => {
        responseText += `**${index + 1}. ${result.title}**\n`;
        responseText += `${result.snippet}\n`;
        responseText += `🔗 Source: ${result.source}\n`;
        responseText += `Link: ${result.url}\n\n`;
      });
      
      responseText += "💡 Click the links above for live, up-to-date information!";
      
      return {
        text: responseText,
        searchResults: searchResults
      };
    }
    
    // Fallback if search fails
    return {
      text: "I'll search the web for real-time information about your query. Please try asking about specific products, prices, or topics you're interested in!",
      searchResults: []
    };
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      text: input.trim(),
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input.trim();
    setInput('');
    setIsTyping(true);

    // Simulate typing delay and web search
    setTimeout(async () => {
      const response = await generateBotResponse(currentInput);
      const botResponse = {
        id: Date.now() + 1,
        sender: 'bot',
        text: response.text || response,
        timestamp: new Date().toLocaleTimeString(),
        searchResults: response.searchResults || []
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800); // Shorter delay since web search has its own delay
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const quickActions = [
    "Track my order",
    "Find best prices",
    "Return policy help",
    "Shipping information"
  ];

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerContent}>
          <div style={styles.logoSection}>
            <div style={styles.logos}>
              <img 
                src="https://vitejs.dev/logo.svg" 
                alt="Vite" 
                style={styles.logo}
              />
              <span style={styles.plus}>+</span>
              <svg style={styles.logo} viewBox="0 0 24 24" fill="#61dafb">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none"/>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                <path d="M2 12h20"/>
              </svg>
            </div>
            <div>
              <h1 style={styles.title}>Vite + React</h1>
              <p style={styles.subtitle}>Buyer Help Chatbot</p>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div style={styles.chatContainer}>
        <div style={styles.chatBox}>
          
          {/* Chat Header */}
          <div style={styles.chatHeader}>
            <div style={styles.chatHeaderContent}>
              <div style={styles.messageIcon}>💬</div>
              <div>
                <h2 style={styles.chatTitle}>Buyer Help Assistant</h2>
                <p style={styles.chatStatus}>Online • Ready to help</p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div style={styles.quickActions}>
            <p style={styles.quickActionsLabel}>Quick actions:</p>
            <div style={styles.quickActionButtons}>
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => setInput(action)}
                  style={styles.quickActionButton}
                >
                  {action}
                </button>
              ))}
            </div>
          </div>

    {/* Messages */}
          <div style={styles.messagesContainer}>
            {messages.map((message) => (
              <div key={message.id}>
                <div
                  style={{
                    ...styles.messageWrapper,
                    justifyContent: message.sender === 'user' ? 'flex-end' : 'flex-start'
                  }}
                >
                  {message.sender === 'bot' && (
                    <div style={styles.botAvatar}>🤖</div>
                  )}
                  
                  <div style={{
                    ...styles.messageBubble,
                    ...(message.sender === 'user' ? styles.userMessage : styles.botMessage)
                  }}>
                    <div style={styles.messageText}>{message.text}</div>
                    <div style={styles.messageTime}>{message.timestamp}</div>
                  </div>

                  {message.sender === 'user' && (
                    <div style={styles.userAvatar}>👤</div>
                  )}
                </div>

                {/* Messages */}
{messages.map((message) => (
  <div key={message.id}>
    <div style={{
      ...styles.messageWrapper,
      justifyContent: message.sender === 'user' ? 'flex-end' : 'flex-start'
    }}>
      {message.sender === 'bot' && <div style={styles.botAvatar}>🤖</div>}
      <div style={{
        ...styles.messageBubble,
        ...(message.sender === 'user' ? styles.userMessage : styles.botMessage)
      }}>
        <div style={styles.messageText}>{message.text}</div>
        <div style={styles.messageTime}>{message.timestamp}</div>
      </div>
      {message.sender === 'user' && <div style={styles.userAvatar}>👤</div>}
    </div>

    {/* Search Results */}
    {message.searchResults && message.searchResults.length > 0 && (
      <div style={styles.searchResults}>
        {message.searchResults.map((result, index) => (
          <div key={index} style={styles.searchResult}>
            ...
          </div>
        ))}
      </div>
    )}
  </div>
))}

{/* Typing Indicator */}
{isTyping && (
  <div style={styles.messageWrapper}>
    <div style={styles.botAvatar}>🤖</div>
    <div style={{...styles.messageBubble, ...styles.botMessage}}>
      <div style={styles.typingIndicator}>
        <div style={styles.typingDot}></div>
        <div style={{...styles.typingDot, animationDelay: '0.2s'}}></div>
        <div style={{...styles.typingDot, animationDelay: '0.4s'}}></div>
      </div>
    </div>
  </div>
)}

 

          {/* Input */}
          <div style={styles.inputContainer}>
            <div style={styles.inputWrapper}>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Type your message here..."
                style={styles.input}
                disabled={!input.trim() || isTyping || isSearching}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || isTyping || isSearching}
                style={{
                  ...styles.sendButton,
                  opacity: (!input.trim() || isTyping || isSearching) ? 0.5 : 1
                }}
              >
                Send ➤
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    fontFamily: 'system-ui, -apple-system, sans-serif'
  },
  header: {
    backgroundColor: 'white',
    borderBottom: '1px solid #e5e7eb',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
  },
  headerContent: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '1rem'
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem'
  },
  logos: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem'
  },
  logo: {
    width: '2rem',
    height: '2rem'
  },
  plus: {
    fontSize: '2rem',
    fontWeight: 'bold'
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: '#1f2937',
    margin: 0
  },
  subtitle: {
    color: '#6b7280',
    margin: 0
  },
  chatContainer: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '2rem'
  },
  chatBox: {
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)',
    overflow: 'hidden'
  },
  chatHeader: {
    background: 'linear-gradient(90deg, #3b82f6, #6366f1)',
    color: 'white',
    padding: '1rem'
  },
  chatHeaderContent: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem'
  },
  messageIcon: {
    fontSize: '1.5rem'
  },
  chatTitle: {
    fontWeight: '600',
    margin: 0
  },
  chatStatus: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: '0.875rem',
    margin: 0
  },
  quickActions: {
    padding: '1rem',
    backgroundColor: '#f9fafb',
    borderBottom: '1px solid #e5e7eb'
  },
  quickActionsLabel: {
    fontSize: '0.875rem',
    color: '#6b7280',
    margin: '0 0 0.5rem 0'
  },
  quickActionButtons: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '0.5rem'
  },
  quickActionButton: {
    padding: '0.25rem 0.75rem',
    backgroundColor: 'white',
    borderRadius: '1rem',
    fontSize: '0.875rem',
    border: '1px solid #d1d5db',
    cursor: 'pointer',
    transition: 'all 0.2s',
    ':hover': {
      backgroundColor: '#dbeafe',
      borderColor: '#93c5fd'
    }
  },
  messagesContainer: {
    height: '400px',
    overflowY: 'auto',
    padding: '1rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem'
  },
  messageWrapper: {
    display: 'flex',
    gap: '0.75rem',
    alignItems: 'flex-start'
  },
  botAvatar: {
    width: '2rem',
    height: '2rem',
    backgroundColor: '#dbeafe',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    fontSize: '1rem'
  },
  userAvatar: {
    width: '2rem',
    height: '2rem',
    backgroundColor: '#e5e7eb',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    fontSize: '1rem'
  },
  messageBubble: {
    maxWidth: '70%',
    padding: '0.75rem 1rem',
    borderRadius: '1rem'
  },
  userMessage: {
    backgroundColor: '#3b82f6',
    color: 'white',
    borderBottomRightRadius: '0.25rem'
  },
  botMessage: {
    backgroundColor: '#f3f4f6',
    color: '#1f2937',
    borderBottomLeftRadius: '0.25rem'
  },
  messageText: {
    fontSize: '0.875rem',
    lineHeight: '1.4'
  },
  messageTime: {
    fontSize: '0.75rem',
    marginTop: '0.25rem',
    opacity: 0.7
  },
  typingIndicator: {
    display: 'flex',
    gap: '0.25rem'
  },
  typingDot: {
    width: '0.5rem',
    height: '0.5rem',
    backgroundColor: '#6b7280',
    borderRadius: '50%',
    animation: 'bounce 1.4s infinite'
  },
  inputContainer: {
    padding: '1rem',
    borderTop: '1px solid #e5e7eb',
    backgroundColor: 'white'
  },
  inputWrapper: {
    display: 'flex',
    gap: '0.75rem'
  },
  input: {
    flex: 1,
    padding: '0.75rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '0.5rem',
    fontSize: '1rem',
    outline: 'none',
    transition: 'border-color 0.2s',
    ':focus': {
      borderColor: '#3b82f6',
      boxShadow: '0 0 0 3px rgba(59,130,246,0.1)'
    }
  },
  sendButton: {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#3b82f6',
    color: 'white',
    border: 'none',
    borderRadius: '0.5rem',
    fontSize: '1rem',
    fontWeight: '500',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    ':hover': {
      backgroundColor: '#2563eb'
    }
  },
  searchResults: {
    marginLeft: '2.75rem',
    marginTop: '1rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  searchResult: {
    border: '1px solid #e5e7eb',
    borderRadius: '0.75rem',
    padding: '1rem',
    backgroundColor: 'white',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    transition: 'box-shadow 0.2s',
    ':hover': {
      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
    }
  },
  searchResultHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '0.5rem'
  },
  searchResultTitle: {
    fontSize: '1rem',
    fontWeight: '600',
    margin: 0,
    flex: 1
  },
  searchResultLink: {
    color: '#2563eb',
    textDecoration: 'none',
    ':hover': {
      textDecoration: 'underline'
    }
  },
  searchResultSource: {
    fontSize: '0.75rem',
    color: '#6b7280',
    marginLeft: '0.5rem',
    flexShrink: 0
  },
  searchResultSnippet: {
    fontSize: '0.875rem',
    color: '#4b5563',
    lineHeight: '1.5',
    margin: '0 0 0.75rem 0'
  },
  searchResultFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  liveIndicator: {
    fontSize: '0.75rem',
    color: '#059669',
    fontWeight: '500'
  },
  visitButton: {
    fontSize: '0.75rem',
    color: '#2563eb',
    textDecoration: 'none',
    padding: '0.25rem 0.75rem',
    backgroundColor: '#f3f4f6',
    borderRadius: '0.375rem',
    transition: 'background-color 0.2s',
    ':hover': {
      backgroundColor: '#e5e7eb'
    }
  },
  searchingText: {
    fontSize: '0.875rem',
    color: '#6b7280',
    fontStyle: 'italic'
  }
};

export default App;