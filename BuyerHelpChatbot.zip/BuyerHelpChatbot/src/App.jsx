import React, { useState, useRef, useEffect } from 'react';

const App = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'bot',
      text: "Hello! I'm your Buyer Help Assistant. I can help you with shopping, orders, and product information. What can I help you with today?",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const searchWeb = async (query) => {
    setIsSearching(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const searchQuery = encodeURIComponent(query);
      const searchResults = [];
      const lower = query.toLowerCase();
      
      if (lower.includes('price') || lower.includes('buy') || lower.includes('laptop') || lower.includes('phone') || lower.includes('headphone')) {
        searchResults.push({
          title: `Best ${query} - Current Prices & Reviews 2025`,
          snippet: `Compare prices for ${query} across top retailers. Find deals, specs, and user reviews from Amazon, Best Buy, and more.`,
          url: `https://www.google.com/search?q=${searchQuery}+price+comparison`,
          source: "Live Web Search"
        });
        
        searchResults.push({
          title: `${query} - Shopping Results & Deals`,
          snippet: `Shop for ${query} with current pricing, availability, and shipping info. Real-time results from major retailers.`,
          url: `https://shopping.google.com/search?q=${searchQuery}`,
          source: "Google Shopping"
        });
      } else {
        searchResults.push({
          title: `${query} - Latest Information & Updates`,
          snippet: `Current information about ${query}. Real-time results, news, and relevant details.`,
          url: `https://www.google.com/search?q=${searchQuery}`,
          source: "Live Web Search"
        });
      }
      
      setIsSearching(false);
      return searchResults;
      
    } catch (error) {
      setIsSearching(false);
      console.error('Search failed:', error);
      return [];
    }
  };

  const generateBotResponse = async (userMessage) => {
    const searchResults = await searchWeb(userMessage);
    
    if (searchResults.length > 0) {
      return {
        text: `I searched the web for "${userMessage}" and found these current results:`,
        searchResults: searchResults
      };
    }
    
    return {
      text: "I'll search the web for real-time information. Try asking about specific products or prices!",
      searchResults: []
    };
  };

  const sendMessage = async () => {
    if (!input.trim() || isTyping || isSearching) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      text: input.trim(),
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input.trim();
    setInput('');
    setIsTyping(true);

    setTimeout(async () => {
      const response = await generateBotResponse(currentInput);
      const botResponse = {
        id: Date.now() + 1,
        sender: 'bot',
        text: response.text,
        timestamp: new Date().toLocaleTimeString(),
        searchResults: response.searchResults || []
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 500);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const quickActions = [
    "Find best laptop prices",
    "Track my order",
    "Compare phone deals",
    "Headphone reviews"
  ];

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div style={styles.headerContent}>
          <div style={styles.logoSection}>
            <div style={styles.logos}>
              <img 
                src="https://vitejs.dev/logo.svg" 
                alt="Vite" 
                style={styles.logo}
              />
              <span style={styles.plus}>+</span>
              <svg style={styles.logo} viewBox="0 0 24 24" fill="#61dafb">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" fill="none"/>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                <path d="M2 12h20"/>
              </svg>
            </div>
            <div>
              <h1 style={styles.title}>Vite + React</h1>
              <p style={styles.subtitle}>Buyer Help Chatbot with Live Web Search</p>
            </div>
          </div>
        </div>
      </div>

      <div style={styles.chatContainer}>
        <div style={styles.chatBox}>
          <div style={styles.chatHeader}>
            <div style={styles.chatHeaderContent}>
              <div style={styles.messageIcon}>💬</div>
              <div>
                <h2 style={styles.chatTitle}>Buyer Help Assistant</h2>
                <p style={styles.chatStatus}>Online • Ready to help</p>
              </div>
            </div>
          </div>

          <div style={styles.quickActions}>
            <p style={styles.quickActionsLabel}>Quick actions:</p>
            <div style={styles.quickActionButtons}>
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => setInput(action)}
                  style={styles.quickActionButton}
                >
                  {action}
                </button>
              ))}
            </div>
          </div>

          <div style={styles.messagesContainer}>
            {messages.map((message) => (
              <div key={message.id}>
                <div style={{
                  ...styles.messageWrapper,
                  justifyContent: message.sender === 'user' ? 'flex-end' : 'flex-start'
                }}>
                  {message.sender === 'bot' && <div style={styles.botAvatar}>🤖</div>}
                  
                  <div style={{
                    ...styles.messageBubble,
                    ...(message.sender === 'user' ? styles.userMessage : styles.botMessage)
                  }}>
                    <div style={styles.messageText}>{message.text}</div>
                    <div style={styles.messageTime}>{message.timestamp}</div>
                  </div>

                  {message.sender === 'user' && <div style={styles.userAvatar}>👤</div>}
                </div>

                {message.searchResults && message.searchResults.length > 0 && (
                  <div style={styles.searchResults}>
                    {message.searchResults.map((result, index) => (
                      <div key={index} style={styles.searchResult}>
                        <div style={styles.searchResultHeader}>
                          <h3 style={styles.searchResultTitle}>
                            <a href={result.url} target="_blank" rel="noopener noreferrer" style={styles.searchResultLink}>
                              {result.title}
                            </a>
                          </h3>
                          <span style={styles.searchResultSource}>{result.source}</span>
                        </div>
                        <p style={styles.searchResultSnippet}>{result.snippet}</p>
                        <div style={styles.searchResultFooter}>
                          <span style={styles.liveIndicator}>🔍 Live Result</span>
                          <a href={result.url} target="_blank" rel="noopener noreferrer" style={styles.visitButton}>
                            Visit Site →
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div style={styles.messageWrapper}>
                <div style={styles.botAvatar}>🤖</div>
                <div style={{...styles.messageBubble, ...styles.botMessage}}>
                  <div style={styles.typingIndicator}>
                    <div style={styles.typingDot}></div>
                    <div style={{...styles.typingDot, animationDelay: '0.2s'}}></div>
                    <div style={{...styles.typingDot, animationDelay: '0.4s'}}></div>
                  </div>
                </div>
              </div>
            )}

            {isSearching && (
              <div style={styles.messageWrapper}>
                <div style={styles.botAvatar}>🔍</div>
                <div style={{...styles.messageBubble, ...styles.botMessage}}>
                  <div style={styles.searchingText}>Searching the web...</div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <div style={styles.inputContainer}>
            <div style={styles.inputWrapper}>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Type your message here..."
                style={styles.input}
                disabled={isTyping || isSearching}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || isTyping || isSearching}
                style={{
                  ...styles.sendButton,
                  opacity: (!input.trim() || isTyping || isSearching) ? 0.5 : 1,
                  cursor: (!input.trim() || isTyping || isSearching) ? 'not-allowed' : 'pointer'
                }}
              >
                Send ➤
              </button>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-8px); }
        }
      `}</style>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    fontFamily: 'system-ui, -apple-system, sans-serif'
  },
  header: {
    backgroundColor: 'white',
    borderBottom: '1px solid #e5e7eb',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
  },
  headerContent: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '1rem'
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem'
  },
  logos: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem'
  },
  logo: {
    width: '2rem',
    height: '2rem'
  },
  plus: {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: '#6b7280'
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: '#1f2937',
    margin: 0
  },
  subtitle: {
    color: '#6b7280',
    margin: 0,
    fontSize: '0.875rem'
  },
  chatContainer: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '2rem'
  },
  chatBox: {
    backgroundColor: 'white',
    borderRadius: '12px',
    boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)',
    overflow: 'hidden'
  },
  chatHeader: {
    background: 'linear-gradient(90deg, #3b82f6, #6366f1)',
    color: 'white',
    padding: '1rem'
  },
  chatHeaderContent: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem'
  },
  messageIcon: {
    fontSize: '1.5rem'
  },
  chatTitle: {
    fontWeight: '600',
    margin: 0,
    fontSize: '1.125rem'
  },
  chatStatus: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: '0.875rem',
    margin: 0
  },
  quickActions: {
    padding: '1rem',
    backgroundColor: '#f9fafb',
    borderBottom: '1px solid #e5e7eb'
  },
  quickActionsLabel: {
    fontSize: '0.875rem',
    color: '#6b7280',
    margin: '0 0 0.5rem 0'
  },
  quickActionButtons: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '0.5rem'
  },
  quickActionButton: {
    padding: '0.5rem 1rem',
    backgroundColor: 'white',
    borderRadius: '1rem',
    fontSize: '0.875rem',
    border: '1px solid #d1d5db',
    cursor: 'pointer',
    transition: 'all 0.2s'
  },
  messagesContainer: {
    height: '450px',
    overflowY: 'auto',
    padding: '1rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem'
  },
  messageWrapper: {
    display: 'flex',
    gap: '0.75rem',
    alignItems: 'flex-start'
  },
  botAvatar: {
    width: '2rem',
    height: '2rem',
    backgroundColor: '#dbeafe',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    fontSize: '1rem'
  },
  userAvatar: {
    width: '2rem',
    height: '2rem',
    backgroundColor: '#e5e7eb',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    fontSize: '1rem'
  },
  messageBubble: {
    maxWidth: '70%',
    padding: '0.75rem 1rem',
    borderRadius: '1rem'
  },
  userMessage: {
    backgroundColor: '#3b82f6',
    color: 'white',
    borderBottomRightRadius: '0.25rem'
  },
  botMessage: {
    backgroundColor: '#f3f4f6',
    color: '#1f2937',
    borderBottomLeftRadius: '0.25rem'
  },
  messageText: {
    fontSize: '0.875rem',
    lineHeight: '1.5',
    whiteSpace: 'pre-wrap'
  },
  messageTime: {
    fontSize: '0.75rem',
    marginTop: '0.25rem',
    opacity: 0.7
  },
  typingIndicator: {
    display: 'flex',
    gap: '0.25rem',
    padding: '0.25rem 0'
  },
  typingDot: {
    width: '0.5rem',
    height: '0.5rem',
    backgroundColor: '#6b7280',
    borderRadius: '50%',
    animation: 'bounce 1.4s infinite ease-in-out'
  },
  searchingText: {
    fontSize: '0.875rem',
    color: '#6b7280',
    fontStyle: 'italic'
  },
  searchResults: {
    marginLeft: '2.75rem',
    marginTop: '0.5rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  searchResult: {
    border: '1px solid #e5e7eb',
    borderRadius: '0.75rem',
    padding: '1rem',
    backgroundColor: 'white',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    transition: 'box-shadow 0.2s'
  },
  searchResultHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '0.5rem',
    gap: '0.5rem'
  },
  searchResultTitle: {
    fontSize: '0.9375rem',
    fontWeight: '600',
    margin: 0,
    flex: 1
  },
  searchResultLink: {
    color: '#2563eb',
    textDecoration: 'none'
  },
  searchResultSource: {
    fontSize: '0.75rem',
    color: '#6b7280',
    flexShrink: 0
  },
  searchResultSnippet: {
    fontSize: '0.875rem',
    color: '#4b5563',
    lineHeight: '1.5',
    margin: '0 0 0.75rem 0'
  },
  searchResultFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  liveIndicator: {
    fontSize: '0.75rem',
    color: '#059669',
    fontWeight: '500'
  },
  visitButton: {
    fontSize: '0.75rem',
    color: '#2563eb',
    textDecoration: 'none',
    padding: '0.25rem 0.75rem',
    backgroundColor: '#f3f4f6',
    borderRadius: '0.375rem',
    transition: 'background-color 0.2s',
    fontWeight: '500'
  },
  inputContainer: {
    padding: '1rem',
    borderTop: '1px solid #e5e7eb',
    backgroundColor: 'white'
  },
  inputWrapper: {
    display: 'flex',
    gap: '0.75rem'
  },
  input: {
    flex: 1,
    padding: '0.75rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '0.5rem',
    fontSize: '1rem',
    outline: 'none',
    transition: 'border-color 0.2s'
  },
  sendButton: {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#3b82f6',
    color: 'white',
    border: 'none',
    borderRadius: '0.5rem',
    fontSize: '1rem',
    fontWeight: '500',
    cursor: 'pointer',
    transition: 'all 0.2s',
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem'
  }
};

export default App;